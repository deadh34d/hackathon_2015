<?php
/**
 * Created by PhpStorm.
 * User: development
 * Date: 8/19/2015
 * Time: 6:06 PM
 */
include('view/header.php');
$page = "bare";?>


<div class="container">
<?php include('view/why-idk.php'); ?>
</div>
