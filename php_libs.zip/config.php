<?php
///**
// * Created by PhpStorm.
// * User: development
// * Date: 8/13/2015
// * Time: 8:16 AM
// */
//define('__ROOT__', docroot(__FILE__));
set_include_path(__DIR__);
$debug = false;
$app_path = "/";
$protocol = "http://";
$domain = "idkhomes.com";