<?php include('view/header.php');
$page = 'bare'; ?>
<?php include('view/sidebar.php'); ?>
<div class="container">
    <div class="jumbotron">
        <h3>Page not found. If you believe there should be a page here, feel free to
            <a href="<?php echo $app_path;?>/contact">contact us.</a> and we'll make it right.</h3>
    </div>
    <?php include('view/sidebar.php');?>
</div>

<?php include('view/footer.php');?>