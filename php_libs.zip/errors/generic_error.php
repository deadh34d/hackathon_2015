<?php
/**
 * Created by PhpStorm.
 * User: development
 * Date: 8/11/2015
 * Time: 2:03 PM
 * TODO: fill out this file more
 */
echo 'Generic error'; // here so we don't get a blank page and think we're total failures.
?>
