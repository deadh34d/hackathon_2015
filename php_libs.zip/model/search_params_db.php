<?php
/**
 * Created by PhpStorm.
 * User: development
 * Date: 8/29/2015
 * Time: 5:06 PM
 */
require_once('model/database.class.php');
//$price = [];
//$j = 0;
//for($i = 100000;$i<1500000;$i+=25000){
//
//    $price[]+=$i;
//
//    add_prices($price[$j]);
//    $j++;
//} internal mass insert statement loop

//http://stackoverflow.com/questions/6369887/alternative-to-money-format-function-in-php-on-windows-platform
function get_zips()
{
    $db = Database::connect();
    $query = 'SELECT * FROM zipcodes';
    $statement = $db->prepare($query);
    $statement->execute();
    $elevations = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    sort($elevations);
    return $elevations;
}
function get_locations()
{
    $db = Database::connect();
    $query = 'SELECT * FROM locations';
    $statement = $db->prepare($query);
    $statement->execute();
    $locations = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    sort($locations);
    return $locations;
}
function get_elevations()
{
    $db = Database::connect();
    $query = 'SELECT * FROM elevations';
    $statement = $db->prepare($query);
    $statement->execute();
    $elevations = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    sort($elevations);
    return $elevations;
}

function get_plan_names()
{
    $db = Database::connect();
    $query = 'SELECT * FROM plans';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    return $result;
}
function get_finishes()
{
    $db = Database::connect();
    $query = 'SELECT * FROM finishes';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    return $result;
}

function add_finish($finish) //internal use only
{
    $db = Database::connect();
    $query = 'INSERT INTO finishes (finish) VALUE (:finish)';
    $statement = $db->prepare($query);
    $statement->bindValue(":finish", $finish);
    $statement->execute();
    $statement->closeCursor();
}

function get_lots()
{
    $db = Database::connect();
    $query = 'SELECT * FROM lots';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    return $result;
}

function get_subdivisions()
{
    $db = Database::connect();
    $query = 'SELECT * FROM subdivisions';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    return $result;
}

function toMoney($val, $symbol = '$', $r = 2)
{


    $n = $val;
    $c = is_float($n) ? 1 : number_format($n, $r);
    $d = '.';
    $t = ',';
    $sign = ($n < 0) ? '-' : '';
    $i = $n = number_format(abs($n), $r);
    $j = (($j = strlen($i)) > 3) ? $j % 3 : 0;

    return $symbol . $sign . ($j ? substr($i, 0, $j) + $t : '') . preg_replace('/(\d{3})(?=\d)/', "$1" + $t, substr($i, $j));

}

function get_states()
{
    $db = Database::connect();
    $query = 'SELECT * FROM states';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    sort($result);
    return $result;
}

function get_cities()
{
    $db = Database::connect();
    $query = 'SELECT * FROM cities';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    sort($result);
    return $result;
}

function get_beds()
{
    $db = Database::connect();
    $query = 'SELECT * FROM beds';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    sort($result);
    return $result;
}

function get_baths()
{
    $db = Database::connect();
    $query = 'SELECT * FROM baths';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    sort($result);
    return $result;
}

function get_prices()
{
    $db = Database::connect();
    $query = 'SELECT * FROM prices';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    sort($result);
    return $result;
}

function add_price($price) //internal use only
{
    $db = Database::connect();
    $query = 'INSERT INTO prices (price) VALUE (:price)';
    $statement = $db->prepare($query);
    $statement->bindValue(":price", $price);
    $statement->execute();
    $statement->closeCursor();
}

function get_sqfts()
{
    $db = Database::connect();
    $query = 'SELECT * FROM sqfts';
    $statement = $db->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    return $result;
}

function add_sqft($sqft) //internal use only
{
    $db = Database::connect();
    $query = 'INSERT INTO sqfts (sqft) VALUE (:sqft)';
    $statement = $db->prepare($query);
    $statement->bindValue(":sqft", $sqft);
    $statement->execute();
    $statement->closeCursor();
}