<?php require_once('../config.php');


class Verifier {

    public function verify_lot($input_array){

    }
}