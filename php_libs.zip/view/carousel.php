<?php include('view/header.php'); ?>

<?php $page = 'home'; ?>
    <div class="container homepage">
    <div class="containing-template">
    <div class="row carousel-row">
        <div class="col-xs-12 col-lg-12 slide-row">
            <div class="carousel slide slide-carousel" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target=".carousel" data-slide-to="0" class="active"></li>
                    <li data-target=".carousel" data-slide-to="1"></li>
                    <li data-target=".carousel" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    <div class="item active">
                        <img src="http://www.recoprop.com/wp-content/uploads/house-pond-nature.jpg">
                        <!--                            src="http://www.freshpalace.com/wp-content/uploads/2014/08/Garage-Entrance-Lighting-Contemporary-House-in-Toronto.jpg"-->

                        <!--                            alt="Image">-->

                        <div class="carousel-caption">
                            <h3>Lorem ipsum</h3>

                            <p>Lorem ipsum</p>
                        </div>
                    </div>
                    <div class="item">
                        <img src="http://i.imgur.com/stgmbwl.jpg">
                        <!--                            src="http://charityartsite.com/wp-content/uploads/2015/06/modern-living-rooom-chinese-interior-design-with-regard-to-interesting-design-ideas-chinese-apartment-for-inspiration.jpg"-->

                        <!--                            alt="Image">-->

                        <div class="carousel-caption">
                            <h3></h3>

                            <p>Lorem ipsum</p>
                        </div>
                    </div>
                    <div class="item">
                        <img
                            src="http://www.pennytowercook.com/wp-content/themes/vistas/slides/01_3615-Lexington-Ave_HiRes.jpg">
                        <!--                            src="http://www.home-inspiration.com/wp-content/uploads/2014/12/Bright-Rug-Coffee-Table-Sofa.jpg?4406d3"-->
                        <!--                            -->
                        <!--                            alt="Image">-->

                        <div class="carousel-caption">
                            <h3>Lorem ipsum </h3>

                            <p>Lorem ipsum</p>
                        </div>
                    </div>
                </div>
            </div>
            <br>

        </div>
    </div>
<?php include('view/sidebar.php'); ?>
<?php include('view/footer.php'); ?>