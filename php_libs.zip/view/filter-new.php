<form class="form-inline">
    <div class="form-group">
        <label for="exampleInputName2">Name</label>
        <input type="text" class="form-control" id="exampleInputName2" placeholder="Jane Doe">
        <select id="selectbasic" name="selectbasic" class="form-control">
            <option>200,000</option>
            <option>225,000</option>
            <option>250,000</option>
            <option>275,000</option>
            <option>300,000</option>
            <option>325,000</option>
            <option>350,000</option>
        </select>

        <div>
            <label for='sqft'></label>
            <select id="sqft" name="sqft" class="form-control">
                <option>1,000</option>
                <option>2,000</option>
                <option>3,000</option>
                <option>4,000</option>
                <option>5,000</option>
            </select>
        </div>
        <label for='beds'></label>
        <select id="beds" name="beds" class="form-control">
            <option>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
        </select>
        <label for='selectbasic'></label>
        <select id="selectbasic" name="selectbasic" class="form-control">
            <option>Option one</option>
            <option>Option two</option>
        </select>
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">Email</label>
        <input type="email" class="form-control" id="exampleInputEmail2" placeholder="jane.doe@example.com">
    </div>
    <button type="submit" class="btn btn-default">Send invitation</button>
</form>