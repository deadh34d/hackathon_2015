<div class="col-xs-12 text-center">
    <span class="text-block"> &copy Designeroid.</span>
    <br/>
    <a href="<?php echo $app_path . '/buildertrend/'; ?>"><span>BuilderTrend Login</span></a>
</div>
</div>
<script src="<?php echo $app_path; ?>/libs/jquery-2.1.1.min.js" xmlns="http://www.w3.org/1999/html"></script>
<script async src="<?php echo $app_path; ?>/js/app.js"></script>
<script async src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script async src="<?php echo $app_path; ?>/libs/bootstrap2-toggle.min.js"></script>
<!--        social icons-->
<link rel="stylesheet" media="screen" href="<?php echo $app_path; ?>/css/font-awesome.min.css">
<link rel="stylesheet" media="screen" href="<?php echo $app_path; ?>/css/bootstrap-social.css">
<link rel="stylesheet" media="screen" href="<?php echo $app_path; ?>/css/stateface.css">
<link rel="stylesheet" media="screen" href="<?php echo $app_path; ?>/css/bootstrap2-toggle.min.css">

<!--Google Maps-->
<script async src="https://maps.googleapis.com/maps/api/js?signed_in=true&callback=initMap"></script>

<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

<!--JQuery-->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>


<!--SumoMe-->
<script src="//load.sumome.com/" data-sumo-site-id="763d29a3a24d265ceb9d9339581c8804c4da5cb049e950eaae4604431a699d20" async="async"></script>
</body>
</html>